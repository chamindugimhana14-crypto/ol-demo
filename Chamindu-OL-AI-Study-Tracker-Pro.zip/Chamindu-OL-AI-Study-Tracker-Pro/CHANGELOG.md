# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-08-02

### Added
- Initial public release of O/L AI Study Tracker Pro.
- Exam countdown, subject tracker, tuition manager, and daily study planner.
- Pomodoro timer with sound effects.
- Revision logging system with heatmap visualization.
- Homework and to-do tracker with due dates and reminders.
- Mock exam tracker with mistake logs and improvement notes.
- Notes and PDF/past-paper resource library.
- Global search across subjects, notes, and tasks.
- Export reports module.
- Drizzle ORM schema and PostgreSQL-backed persistence.
- Automatic first-run database initialization and demo data seeding.

### Changed
- Migrated Drizzle Kit configuration from a static JSON file with a hardcoded
  connection string to `drizzle.config.ts`, which reads `DATABASE_URL` from
  the environment.

### Fixed
- Resolved a `react-hooks/set-state-in-effect` lint violation in
  `CountdownClock`.
- Resolved `react/no-unescaped-entities` lint violations across three
  components.

### Security
- Anonymized demo tuition data (phone numbers, WhatsApp numbers, and
  addresses) in the database seed file prior to open-sourcing.
