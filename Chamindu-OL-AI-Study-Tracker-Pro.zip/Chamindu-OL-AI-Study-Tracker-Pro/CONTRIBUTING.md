# Contributing to O/L AI Study Tracker Pro

Thanks for your interest in contributing! This document covers the basics of getting set up and submitting changes.

## Getting Started

1. Fork the repository and clone your fork.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Copy the environment template and configure your local PostgreSQL connection:
   ```bash
   cp .env.example .env
   ```
4. Start the dev server:
   ```bash
   npm run dev
   ```

## Development Workflow

- Create a feature branch off `main`:
  ```bash
  git checkout -b feature/your-feature-name
  ```
- Keep changes focused — one feature or fix per pull request.
- Before committing, make sure the project builds cleanly and passes checks:
  ```bash
  npm run typecheck
  npm run lint
  npm run build
  ```

## Commit Messages

Use clear, descriptive commit messages, e.g.:

```
feat: add revision heatmap to dashboard
fix: correct Pomodoro timer reset bug
docs: update database setup instructions
```

## Database Changes

If you modify `src/db/schema.ts`, generate a corresponding migration:

```bash
npm run db:generate
```

Commit the generated files under `drizzle/` along with your schema change.

## Pull Requests

- Describe what the change does and why.
- Reference any related issues.
- Include screenshots for UI changes where relevant.
- Ensure `npm run build` passes before requesting review.

## Code Style

- TypeScript with `strict` mode enabled — avoid `any` where possible.
- Follow the existing component patterns in `src/components/`.
- Use Tailwind CSS utility classes for styling; keep the dark-luxury visual theme consistent.

## Reporting Issues

When filing an issue, please include:
- Steps to reproduce
- Expected vs. actual behavior
- Environment details (OS, Node version, browser)

## Code of Conduct

Be respectful and constructive. This is a community project — treat other contributors the way you'd want to be treated.
