CREATE TABLE "app_settings" (
	"id" serial PRIMARY KEY NOT NULL,
	"theme" varchar(20) DEFAULT 'dark' NOT NULL,
	"accent_color" varchar(20) DEFAULT '#FFD700' NOT NULL,
	"notifications" boolean DEFAULT true NOT NULL,
	"auto_save" boolean DEFAULT true NOT NULL,
	"keyboard_shortcuts" boolean DEFAULT true NOT NULL,
	"backup_json" text DEFAULT '' NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "chapters" (
	"id" serial PRIMARY KEY NOT NULL,
	"subject_id" integer NOT NULL,
	"title" varchar(200) NOT NULL,
	"status" varchar(30) DEFAULT 'pending' NOT NULL,
	"difficulty" varchar(20) DEFAULT 'medium' NOT NULL,
	"priority" varchar(20) DEFAULT 'medium' NOT NULL,
	"progress" integer DEFAULT 0 NOT NULL,
	"notes" text DEFAULT '' NOT NULL,
	"resources" text DEFAULT '' NOT NULL,
	"homework" text DEFAULT '' NOT NULL,
	"estimated_minutes" integer DEFAULT 0 NOT NULL,
	"actual_minutes" integer DEFAULT 0 NOT NULL,
	"revision_counter" integer DEFAULT 0 NOT NULL,
	"completion_date" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "homework_items" (
	"id" serial PRIMARY KEY NOT NULL,
	"subject_id" integer,
	"title" varchar(200) NOT NULL,
	"priority" varchar(20) DEFAULT 'medium' NOT NULL,
	"due_date" timestamp with time zone,
	"reminder" boolean DEFAULT true NOT NULL,
	"notes" text DEFAULT '' NOT NULL,
	"status" varchar(20) DEFAULT 'pending' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "mock_exams" (
	"id" serial PRIMARY KEY NOT NULL,
	"subject_id" integer,
	"exam_date" timestamp with time zone DEFAULT now() NOT NULL,
	"marks" numeric(6, 2) DEFAULT '0' NOT NULL,
	"percentage" numeric(5, 2) DEFAULT '0' NOT NULL,
	"grade" varchar(10) DEFAULT 'N/A' NOT NULL,
	"time_taken_minutes" integer DEFAULT 0 NOT NULL,
	"mistakes" text DEFAULT '' NOT NULL,
	"wrong_questions" text DEFAULT '' NOT NULL,
	"weak_areas" text DEFAULT '' NOT NULL,
	"improvement_notes" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "notes" (
	"id" serial PRIMARY KEY NOT NULL,
	"subject_id" integer,
	"title" varchar(180) NOT NULL,
	"content" text DEFAULT '' NOT NULL,
	"tags" text DEFAULT '' NOT NULL,
	"category" varchar(60) DEFAULT 'general' NOT NULL,
	"bookmarked" boolean DEFAULT false NOT NULL,
	"attachment_url" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "pdf_resources" (
	"id" serial PRIMARY KEY NOT NULL,
	"subject_id" integer,
	"title" varchar(200) NOT NULL,
	"type" varchar(50) DEFAULT 'Past Paper' NOT NULL,
	"year" integer DEFAULT 2024,
	"medium" varchar(20) DEFAULT 'Sinhala' NOT NULL,
	"url" text DEFAULT '' NOT NULL,
	"file_size" varchar(30) DEFAULT '1.5 MB' NOT NULL,
	"bookmarked" boolean DEFAULT false NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "revision_logs" (
	"id" serial PRIMARY KEY NOT NULL,
	"subject_id" integer,
	"topic" varchar(200) NOT NULL,
	"type" varchar(30) DEFAULT 'daily' NOT NULL,
	"minutes" integer DEFAULT 30 NOT NULL,
	"weak_topic" boolean DEFAULT false NOT NULL,
	"reviewed_at" timestamp with time zone DEFAULT now() NOT NULL,
	"notes" text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "study_sessions" (
	"id" serial PRIMARY KEY NOT NULL,
	"subject_id" integer,
	"title" varchar(200) NOT NULL,
	"slot" varchar(20) DEFAULT 'morning' NOT NULL,
	"planned_minutes" integer DEFAULT 60 NOT NULL,
	"actual_minutes" integer DEFAULT 0 NOT NULL,
	"date" timestamp with time zone DEFAULT now() NOT NULL,
	"completed" boolean DEFAULT false NOT NULL,
	"carried_forward" boolean DEFAULT false NOT NULL,
	"notes" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "subjects" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" varchar(120) NOT NULL,
	"color" varchar(20) DEFAULT '#FFD700' NOT NULL,
	"icon" varchar(40) DEFAULT '📘' NOT NULL,
	"teacher" varchar(120) DEFAULT '',
	"tuition_institute" varchar(180) DEFAULT '',
	"priority" varchar(20) DEFAULT 'medium' NOT NULL,
	"difficulty" varchar(20) DEFAULT 'medium' NOT NULL,
	"total_chapters" integer DEFAULT 0 NOT NULL,
	"completed_chapters" integer DEFAULT 0 NOT NULL,
	"estimated_study_hours" numeric(8, 2) DEFAULT '0' NOT NULL,
	"actual_study_hours" numeric(8, 2) DEFAULT '0' NOT NULL,
	"notes" text DEFAULT '' NOT NULL,
	"resources" text DEFAULT '' NOT NULL,
	"revision_count" integer DEFAULT 0 NOT NULL,
	"mock_exam_average" numeric(5, 2) DEFAULT '0' NOT NULL,
	"weak_topics" text DEFAULT '' NOT NULL,
	"strong_topics" text DEFAULT '' NOT NULL,
	"archived" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "todo_items" (
	"id" serial PRIMARY KEY NOT NULL,
	"title" varchar(200) NOT NULL,
	"priority" varchar(20) DEFAULT 'medium' NOT NULL,
	"recurring" varchar(20) DEFAULT 'none' NOT NULL,
	"due_date" timestamp with time zone,
	"completed" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "tuition_classes" (
	"id" serial PRIMARY KEY NOT NULL,
	"subject_id" integer,
	"teacher_name" varchar(120) NOT NULL,
	"institute" varchar(180) DEFAULT '' NOT NULL,
	"mode" varchar(20) DEFAULT 'physical' NOT NULL,
	"address" text DEFAULT '' NOT NULL,
	"contact_number" varchar(40) DEFAULT '' NOT NULL,
	"whatsapp" varchar(40) DEFAULT '' NOT NULL,
	"class_day" varchar(20) NOT NULL,
	"class_time" varchar(20) NOT NULL,
	"duration_minutes" integer DEFAULT 120 NOT NULL,
	"monthly_fee" numeric(10, 2) DEFAULT '0' NOT NULL,
	"attendance_count" integer DEFAULT 0 NOT NULL,
	"upcoming_date" timestamp with time zone,
	"homework" text DEFAULT '' NOT NULL,
	"notes" text DEFAULT '' NOT NULL,
	"reminder_enabled" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "chapters" ADD CONSTRAINT "chapters_subject_id_subjects_id_fk" FOREIGN KEY ("subject_id") REFERENCES "public"."subjects"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "homework_items" ADD CONSTRAINT "homework_items_subject_id_subjects_id_fk" FOREIGN KEY ("subject_id") REFERENCES "public"."subjects"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "mock_exams" ADD CONSTRAINT "mock_exams_subject_id_subjects_id_fk" FOREIGN KEY ("subject_id") REFERENCES "public"."subjects"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notes" ADD CONSTRAINT "notes_subject_id_subjects_id_fk" FOREIGN KEY ("subject_id") REFERENCES "public"."subjects"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pdf_resources" ADD CONSTRAINT "pdf_resources_subject_id_subjects_id_fk" FOREIGN KEY ("subject_id") REFERENCES "public"."subjects"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "revision_logs" ADD CONSTRAINT "revision_logs_subject_id_subjects_id_fk" FOREIGN KEY ("subject_id") REFERENCES "public"."subjects"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "study_sessions" ADD CONSTRAINT "study_sessions_subject_id_subjects_id_fk" FOREIGN KEY ("subject_id") REFERENCES "public"."subjects"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "tuition_classes" ADD CONSTRAINT "tuition_classes_subject_id_subjects_id_fk" FOREIGN KEY ("subject_id") REFERENCES "public"."subjects"("id") ON DELETE set null ON UPDATE no action;