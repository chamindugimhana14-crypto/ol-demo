# Chamindu Gimhana's O/L AI Study Tracker Pro

A premium, offline-first study management system built for Sri Lankan G.C.E. Ordinary Level (O/L) private candidates. It combines a subject tracker, tuition manager, study planner, Pomodoro timer, and exam analytics into a single dark-luxury dashboard.

## Features

- 🎯 **Exam Countdown** — live countdown to the O/L examination window
- 📚 **Subject Tracker** — chapters, progress, priority, and difficulty per subject
- 🧑‍🏫 **Tuition Manager** — class schedules, fees, attendance, and homework per tutor
- 🗓️ **Daily Study Planner** — plan and log study sessions by time slot
- ⏱️ **Pomodoro Timer** — focused study sessions with sound effects
- 🔁 **Revision System** — revision logs, streaks, and a revision heatmap
- 📝 **Homework & To-Do Tracker** — due dates, priorities, and reminders
- 🧪 **Mock Exam Tracker** — scores, mistakes, and improvement notes
- 📊 **Statistics Dashboard** — progress and performance at a glance
- 📄 **Notes & PDF Library** — bookmarked notes and past-paper resources
- 🔍 **Global Search** — quickly find subjects, notes, and tasks
- 🗂️ **Export Reports** — generate study reports

## Tech Stack

**Frontend**
- [Next.js](https://nextjs.org/) 16 (App Router, Turbopack)
- [React](https://react.dev/) 19
- [TypeScript](https://www.typescriptlang.org/)
- [Tailwind CSS](https://tailwindcss.com/) 4
- [Framer Motion](https://www.framer.com/motion/) for animation
- [lucide-react](https://lucide.dev/) for icons

**Backend**
- [Next.js Route Handlers](https://nextjs.org/docs/app/building-your-application/routing/route-handlers) (API routes)
- [Drizzle ORM](https://orm.drizzle.team/) with [`node-postgres`](https://node-postgres.com/)
- [PostgreSQL](https://www.postgresql.org/)

> **Note:** This project uses **PostgreSQL via Drizzle ORM**, not SQLite/Prisma. Make sure you have a PostgreSQL instance available (local, Docker, or a hosted provider) before running the app.

## Project Structure

```
.
├── src/
│   ├── app/
│   │   ├── api/              # Route handlers (subjects, homework, mock-exams, study-sessions, health)
│   │   ├── actions.ts         # Server actions
│   │   ├── layout.tsx         # Root layout
│   │   ├── page.tsx           # Home page
│   │   └── globals.css        # Global styles
│   ├── components/            # UI components (dashboard modules, modals, widgets)
│   └── db/
│       ├── index.ts           # Drizzle client / connection pool
│       ├── init.ts            # First-run table creation + demo seed data
│       └── schema.ts          # Drizzle schema definitions
├── drizzle/                   # Generated SQL migrations
├── drizzle.config.ts          # Drizzle Kit configuration
├── .env.example                # Environment variable template
├── package.json
└── tsconfig.json
```

## Getting Started

### Prerequisites

- Node.js 20+
- A running PostgreSQL database (local install, Docker, or a hosted service such as Supabase/Neon/Railway)

### Installation

```bash
npm install
```

### Environment Setup

Copy the example environment file and fill in your database connection string:

```bash
cp .env.example .env
```

```env
DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
```

### Database Setup

This project uses **Drizzle ORM**. On first run, the app automatically creates its tables and seeds demo data via `src/db/init.ts` — no manual migration step is required to get started locally.

If you'd rather manage the schema explicitly with Drizzle Kit:

```bash
# Generate SQL migration files from the schema
npm run db:generate

# Apply migrations to your database
npm run db:migrate

# (Optional) Open Drizzle Studio to browse your data
npm run db:studio
```

### Run the Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) to view the app.

### Build for Production

```bash
npm run build
npm run start
```

## Usage Guide

1. **Subjects tab** — add your O/L subjects, track chapter-by-chapter progress, and log weak/strong topics.
2. **Tuition tab** — add tuition classes with schedule, teacher, and fee details; mark attendance and homework.
3. **Planner tab** — plan study sessions by time slot (morning/afternoon/evening/night) and mark them complete.
4. **Pomodoro** — run focused study timers directly from the dashboard.
5. **Revision** — log revision sessions to build a visual revision heatmap and streak.
6. **Mock Exams** — record mock exam results, mistakes, and improvement notes per subject.
7. **Notes & PDFs** — store study notes and bookmark past papers or reference PDFs.
8. **Reports** — export a snapshot of your study progress.

## Available Scripts

| Script | Description |
| --- | --- |
| `npm run dev` | Start the development server |
| `npm run build` | Build the app for production |
| `npm run start` | Start the production server |
| `npm run lint` | Run ESLint |
| `npm run typecheck` | Run the TypeScript compiler in check-only mode |
| `npm run db:generate` | Generate Drizzle SQL migrations from the schema |
| `npm run db:migrate` | Apply Drizzle migrations |
| `npm run db:studio` | Launch Drizzle Studio |

## Contributing

Contributions are welcome. Please see [CONTRIBUTING.md](./CONTRIBUTING.md) for guidelines.

## License

This project is licensed under the [MIT License](./LICENSE).
